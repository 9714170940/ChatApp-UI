console.log("function attached");

//only selected class in line by line

function addingClassActive() {
    let rajash = document.querySelector('.rajash');
    rajash.classList.remove("active");
    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Ajay Meghani</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
}

function addingClassActive1() {
    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Chavda Rajash</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
}

function addingClassActive2() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Vora Avni</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    
}

function addingClassActive3() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Mayur Kapadi</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/jonathansidwell.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/jonathansidwell.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/jonathansidwell.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/jonathansidwell.png" alt="" />`;
    
}

function addingClassActive4() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Rakesh Sir</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
}

function addingClassActive5() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Niraj Savaliya</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/haroldgunderson.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/haroldgunderson.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/haroldgunderson.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/haroldgunderson.png" alt="" />`;
}

function addingClassActive6() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Kishan Savaliya</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/danielhardman.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/danielhardman.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/danielhardman.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/danielhardman.png" alt="" />`;
}

function addingClassActive7() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Dharti Sarvaiya</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/katrinabennett.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/katrinabennett.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/katrinabennett.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/katrinabennett.png" alt="" />`;
}

function addingClassActive8() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Amit Kapadi</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/charlesforstman.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/charlesforstman.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/charlesforstman.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/charlesforstman.png" alt="" />`;
}

function addingClassActive9() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Anita Mem</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/jessicapearson.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/jessicapearson.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/jessicapearson.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/jessicapearson.png" alt="" />`;
}

function addingClassActive10() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Rohit Meghani</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />`;
}

function addingClassActive11() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Chovatiya Rajash</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />`;
}

function addingClassActive12() {

    let online_name = document.getElementById('online-name');
    online_name.innerHTML = `<p>Sinroja Prince</p>`;
    let user_img = document.querySelector('.user_img');
    user_img.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img = document.querySelector('.sent_img');
    sent_img.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img1 = document.querySelector('.sent_img1');
    sent_img1.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;
    let sent_img2 = document.querySelector('.sent_img2');
    sent_img2.innerHTML = `<img src="http://emilcarlsson.se/assets/rachelzane.png" alt="" />`;

}